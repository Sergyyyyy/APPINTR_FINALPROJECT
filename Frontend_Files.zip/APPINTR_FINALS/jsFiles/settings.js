// const API_BASE_URL = 'http://127.0.0.1:8000/api';

// // 1. Fetch and display the current rate on load
// async function loadCurrentRate() {
//     try {
//         const response = await fetch(`${API_BASE_URL}/settings/`);
//         const data = await response.json();
        
//         if (data.hourly_rate) {
//             document.getElementById('currentRateDisplay').textContent = `₱${data.hourly_rate}`;
//         }
//     } catch (error) {
//         console.error("Error fetching rate:", error);
//         document.getElementById('currentRateDisplay').textContent = "₱Error";
//     }
// }

// // 2. Handle the form submission to update the rate
// document.getElementById('updateRateForm').addEventListener('submit', async function(e) {
//     e.preventDefault(); // Prevent page reload
    
//     const newRate = document.getElementById('newRateInput').value;
//     const updateMessage = document.getElementById('updateMessage');
    
//     try {
//         const response = await fetch(`${API_BASE_URL}/settings/`, {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json',
//             },
//             body: JSON.stringify({ hourly_rate: newRate })
//         });
        
//         if (response.ok) {
//             const data = await response.json();
            
//             // Update the big display
//             document.getElementById('currentRateDisplay').textContent = `₱${data.hourly_rate}`;
            
//             // Clear the input and show success message
//             document.getElementById('newRateInput').value = '';
//             updateMessage.style.display = 'block';
            
//             // Hide the success message after 3 seconds
//             setTimeout(() => {
//                 updateMessage.style.display = 'none';
//             }, 3000);
//         } else {
//             alert("Failed to update rate. Please try again.");
//         }
//     } catch (error) {
//         console.error("Error updating rate:", error);
//         alert("A network error occurred.");
//     }
// });

// // Load data when page opens
// window.onload = loadCurrentRate;

const API_BASE_URL = 'http://127.0.0.1:8000/api';

// 1. Fetch and display the current rate
async function loadCurrentRate() {
    try {
        const response = await fetch(`${API_BASE_URL}/settings/`);
        const data = await response.json();
        
        if (data.hourly_rate) {
            document.getElementById('currentRateDisplay').textContent = `₱${data.hourly_rate}`;
        }
    } catch (error) {
        console.error("Error fetching rate:", error);
        document.getElementById('currentRateDisplay').textContent = "₱Error";
    }
}

// 2. Wait for the HTML to fully load before attaching events
document.addEventListener('DOMContentLoaded', () => {
    
    // Load the current rate immediately upon page load
    loadCurrentRate();

    // Safely grab the form
    const updateForm = document.getElementById('updateRateForm');
    
    // Only add the event listener if the form actually exists
    if (updateForm) {
        updateForm.addEventListener('submit', async function(e) {
            e.preventDefault(); // Prevent page reload
            
            const newRate = document.getElementById('newRateInput').value;
            const updateMessage = document.getElementById('updateMessage');
            
            try {
                const response = await fetch(`${API_BASE_URL}/settings/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ hourly_rate: newRate })
                });
                
                if (response.ok) {
                    const data = await response.json();
                    
                    // Update the big display
                    document.getElementById('currentRateDisplay').textContent = `₱${data.hourly_rate}`;
                    
                    // Clear the input and show success message
                    document.getElementById('newRateInput').value = '';
                    updateMessage.style.display = 'block';
                    
                    // Hide the success message after 3 seconds
                    setTimeout(() => {
                        updateMessage.style.display = 'none';
                    }, 3000);
                } else {
                    alert("Failed to update rate. Please try again.");
                }
            } catch (error) {
                console.error("Error updating rate:", error);
                alert("A network error occurred.");
            }
        });
    } else {
        console.error("Could not find 'updateRateForm' in the HTML.");
    }
});