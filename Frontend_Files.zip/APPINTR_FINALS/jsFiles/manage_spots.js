const API_BASE_URL = 'http://127.0.0.1:8000/api';

// 1. Fetch and Display All Spots
async function loadSpots() {
    const container = document.getElementById('spotsData');
    container.innerHTML = '<div class="text-center py-4 text-muted">Loading spots...</div>';

    try {
        const response = await fetch(`${API_BASE_URL}/spots/`);
        const spots = await response.json();
        
        container.innerHTML = ''; // Clear loading

        if (spots.length === 0) {
            container.innerHTML = '<div class="text-center py-4 text-muted">No parking spots found.</div>';
            return;
        }

        spots.forEach(spot => {
            const statusText = spot.is_occupied ? 'Occupied' : 'Unoccupied';
            
            // Generate the HTML row
            const rowHTML = `
                <div class="data-row px-3">
                    <span style="flex: 1.5"><strong>${spot.spot_number}</strong></span>
                    <span style="flex: 2; text-align: center;">${statusText}</span>
                    <span style="flex: 1; text-align: right;">
                        <button class="btn btn-sm btn-warning" onclick="showEditSpotModal(${spot.id}, '${spot.spot_number}')">Edit</button>
                        <button class="btn btn-sm btn-danger" onclick="showDeleteSpotModal(${spot.id}, '${spot.spot_number}')">Delete</button>
                    </span>
                </div>
            `;
            container.innerHTML += rowHTML;
        });
    } catch (error) {
        console.error("Error loading spots:", error);
    }
}

window.onload = loadSpots;

// 1. Initialize the Bootstrap modal in your JS
const addSpotModal = new bootstrap.Modal(document.getElementById('addSpotModal'));

// 2. Function attached to your main "Add Spot" button on the page
function showAddSpotModal() {
    // Clear any old text in the input
    document.getElementById('newSpotNameInput').value = '';
    // Show the nice modal
    addSpotModal.show();
}

// 3. Attach a click listener to the "Add Spot" button INSIDE the modal
document.getElementById('confirmAddSpotBtn').addEventListener('click', async () => {
    const spotName = document.getElementById('newSpotNameInput').value.trim();
    
    if (!spotName) {
        alert("Please enter a spot name.");
        return;
    }

    try {
        // YOUR EXISTING API POST REQUEST GOES HERE
        const response = await fetch(`${API_BASE_URL}/spots/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ spot_number: spotName })
        });

        if (response.ok) {
            // Hide the modal
            addSpotModal.hide();
            // Reload your spots to show the new one
            loadSpots(); 
        } else {
            alert("Failed to add spot.");
        }
    } catch (error) {
        console.error("Error adding spot:", error);
    }
});

// 1. Initialize the Edit Modal
const editSpotModal = new bootstrap.Modal(document.getElementById('editSpotModal'));

// 2. This function is called when the "Edit" button in your table is clicked
function showEditSpotModal(id, currentName) {
    // Fill the modal with the current spot data
    document.getElementById('editSpotId').value = id;
    document.getElementById('editSpotNameInput').value = currentName;
    
    // Show the modal
    editSpotModal.show();
}

// 3. Handle the "Save Changes" button click inside the modal
document.getElementById('confirmEditSpotBtn').addEventListener('click', async () => {
    const spotId = document.getElementById('editSpotId').value;
    const newName = document.getElementById('editSpotNameInput').value.trim();

    if (!newName) {
        alert("Spot name cannot be empty.");
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/spots/${spotId}/`, {
            method: 'PUT', // or 'PATCH' depending on your Django view
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ spot_number: newName })
        });

        if (response.ok) {
            editSpotModal.hide();
            loadSpots(); // Refresh your table
        } else {
            alert("Failed to update spot.");
        }
    } catch (error) {
        console.error("Error updating spot:", error);
    }
});

// 1. Initialize the Delete Modal
const deleteSpotModal = new bootstrap.Modal(document.getElementById('deleteSpotModal'));

// 2. Show the modal and prepare the data
function showDeleteSpotModal(id, spotNumber) {
    document.getElementById('deleteSpotId').value = id;
    document.getElementById('deleteSpotNameDisplay').textContent = spotNumber;
    deleteSpotModal.show();
}

// 3. Handle the actual deletion
document.getElementById('confirmDeleteSpotBtn').addEventListener('click', async () => {
    const spotId = document.getElementById('deleteSpotId').value;

    try {
        const response = await fetch(`${API_BASE_URL}/spots/${spotId}/`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            deleteSpotModal.hide();
            loadSpots(); // Refresh the list
        } else {
            alert("Failed to delete spot. It might be currently occupied.");
        }
    } catch (error) {
        console.error("Error deleting spot:", error);
    }
});