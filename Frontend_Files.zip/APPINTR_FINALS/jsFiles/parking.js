const API_BASE_URL = 'http://127.0.0.1:8000/api';

// Helper: Formats ISO date string from backend to readable AM/PM format (matches wireframe: 05:55 AM)
function formatTimeAMPM(dateString) {
    const date = new Date(dateString);
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    return `${hours}:${minutes} ${ampm}`;
}

// 1. Initial State Load: Available Spots for Dropdown
async function loadAvailableSpots() {
    const select = document.getElementById('spotSelect');
    select.innerHTML = '<option value="">Loading spots...</option>';

    try {
        const response = await fetch(`${API_BASE_URL}/spots/available/`);
        const spots = await response.json();
        
        select.innerHTML = '<option value="">Assign Parking Spot</option>'; // Clear loading text
        
        if (spots.length === 0) {
            select.innerHTML = '<option value="">LOT IS FULL</option>';
            return;
        }

        spots.forEach(spot => {
            select.innerHTML += `<option value="${spot.id}">${spot.spot_number}</option>`;
        });
    } catch (error) {
        console.error("Error loading spots:", error);
        select.innerHTML = '<option value="">Error contacting backend</option>';
    }
}

// 2. Initial State Load: Currently Parked Vehicles Table
async function loadParkedList() {
    const listContainer = document.getElementById('activeParkingList');
    listContainer.innerHTML = '<div class="text-center py-4 text-muted">Loading parked vehicles...</div>';

    try {
        const response = await fetch(`${API_BASE_URL}/sessions/active/`);
        const sessions = await response.json();
        
        listContainer.innerHTML = ''; // Clear loading text

        if (sessions.length === 0) {
            listContainer.innerHTML = '<div class="text-center py-4 text-muted">No vehicles currently parked.</div>';
            return;
        }

        sessions.forEach(session => {
            const formattedTime = formatTimeAMPM(session.time_in);
            
            // Construct the styled "parking row thin card" exactly like wireframe
            const parkingRowHTML = `
                <div class="parking-row px-3">
                    <span style="flex: 2"><strong>${session.plate_number}</strong></span>
                    <span style="flex: 1.5">${session.spot_number}</span>
                    <span style="flex: 1.5">${formattedTime}</span>
                    <span style="flex: 1; text-align: center;">
                        <button onclick="handleCheckOut(${session.id}, '${session.plate_number}')" class="btn btn-checkout-red">Check-Out</button>
                    </span>
                </div>
            `;
            listContainer.innerHTML += parkingRowHTML;
        });
    } catch (error) {
        console.error("Error loading parked list:", error);
    }
}

// 3. Operational Handler: Handle Form Check-In Submission
document.getElementById('checkInForm').addEventListener('submit', async function(e) {
    e.preventDefault(); // Stop standard page refresh
    
    const plateInput = document.getElementById('plateInput');
    const spotSelect = document.getElementById('spotSelect');

    const formData = {
        plate_number: plateInput.value,
        spot_id: spotSelect.value
    };

    try {
        const response = await fetch(`${API_BASE_URL}/check-in/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        if (response.ok) {
            alert(`Checked-in successful for ${plateInput.value}`);
            // Clear inputs
            plateInput.value = '';
            spotSelect.value = '';
            // Refresh the UI to reflect changes immediately
            loadAvailableSpots();
            loadParkedList();
        } else {
            const errorData = await response.json();
            alert(`Error checking in: ${errorData.error || 'Please check your inputs'}`);
        }
    } catch (error) {
        console.error("Check-in error:", error);
    }
});

// 4. Operational Handler: Handle Table Check-Out Button Click
async function handleCheckOut(sessionId, plateNumber) {
    // Enhancement: Fast confirmation prompt
    if (!confirm(`Are you sure you want to Check-Out vehicle ${plateNumber}?`)) {
        return; // Attendant canceled
    }

    try {
        // Call backend POST endpoint
        const response = await fetch(`${API_BASE_URL}/check-out/${sessionId}/`, {
            method: 'POST'
        });

        if (response.ok) {
            const data = await response.json();
            // Crucial operational step: Capture and show calculated fee return data
            alert(`Check-Out Successful for ${plateNumber}!\n\nTotal Fee Paid: ₱${data.total_fee}`);
            // Refresh UI state
            loadAvailableSpots();
            loadParkedList();
        } else {
            const errorData = await response.json();
            alert(`Error checking out: ${errorData.error}`);
        }
    } catch (error) {
        console.error("Check-out error:", error);
    }
}

// LOAD UI STATE ON PAGE OPEN
window.onload = function() {
    loadAvailableSpots(); // Fill dropdown
    loadParkedList();     // Fill table
};

// Enhancement for MVP: Automatically refresh the parked list every minute
setInterval(loadParkedList, 60000);