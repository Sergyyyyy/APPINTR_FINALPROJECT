const API_BASE_URL = 'http://127.0.0.1:8000/api';

// Helper: Formats ISO date string to AM/PM format
function formatTimeAMPM(dateString) {
    const date = new Date(dateString);
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    minutes = minutes < 10 ? '0' + minutes : minutes;
    return `${hours}:${minutes} ${ampm}`;
}

// Main update function: Fetches data and updates the UI
async function updateDashboard() {
    try {
        // 1. Fetch Metric Cards Data
        const metricsResponse = await fetch(`${API_BASE_URL}/dashboard/metrics/`);
        const metricsData = await metricsResponse.json();

        document.getElementById('availableSpots').textContent = metricsData.available_spots;
        
        // Format revenue to currency
        const formattedRevenue = `₱${parseFloat(metricsData.total_revenue).toLocaleString('en-US')}`;
        document.getElementById('totalRevenue').textContent = formattedRevenue;

        // 2. Fetch Recent Activity Data
        const recentResponse = await fetch(`${API_BASE_URL}/dashboard/recent/`);
        const recentData = await recentResponse.json();
        const activityList = document.getElementById('recentActivityList');
        activityList.innerHTML = ''; // Clear loading text

        recentData.forEach(item => {
            const formattedTime = formatTimeAMPM(item.time);
            
            const activityRow = `
                <div class="activity-row">
                    <span>${item.action}</span>
                    <span><strong>${item.plate}</strong></span>
                    <span>${item.spot}</span>
                    <span>${formattedTime}</span>
                </div>
            `;
            activityList.innerHTML += activityRow;
        });

    } catch (error) {
        console.error("Dashboard update error:", error);
    }
}

// Load data instantly when the page opens
window.onload = updateDashboard;

// Automatically update the dashboard every 30 seconds
setInterval(updateDashboard, 30000);