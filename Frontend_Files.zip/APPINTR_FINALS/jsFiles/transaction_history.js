const API_BASE_URL = 'http://127.0.0.1:8000/api';

// Helper: Formats ISO date string from backend to readable AM/PM format
function formatTimeAMPM(dateString) {
    if (!dateString) return '--';
    const date = new Date(dateString);
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    return `${hours}:${minutes} ${ampm}`;
}

async function loadTransactions() {
    const container = document.getElementById('transactionData');
    
    try {
        const response = await fetch(`${API_BASE_URL}/transactions/`);
        const transactions = await response.json();
        
        container.innerHTML = ''; // Clear loading text

        if (transactions.length === 0) {
            container.innerHTML = '<div class="text-center py-4 text-white">No completed transactions found.</div>';
            return;
        }

        transactions.forEach(tx => {
            const timeIn = formatTimeAMPM(tx.time_in);
            const timeOut = formatTimeAMPM(tx.time_out);
            const fee = tx.total_fee ? `₱${tx.total_fee}` : '₱0';
            
            // Flex ratios match the header perfectly
            const rowHTML = `
                <div class="data-row px-3">
                    <span style="flex: 1.5"><strong>${tx.plate_number}</strong></span>
                    <span style="flex: 1; text-align: center;">${tx.spot_number}</span>
                    <span style="flex: 1.5; text-align: center;">${timeIn}</span>
                    <span style="flex: 1.5; text-align: center;">${timeOut}</span>
                    <span style="flex: 1; text-align: right; font-weight: bold;">${fee}</span>
                </div>
            `;
            container.innerHTML += rowHTML;
        });
    } catch (error) {
        console.error("Error loading transactions:", error);
        container.innerHTML = '<div class="text-center py-4 text-danger">Failed to load data.</div>';
    }
}

// Load data when page opens
window.onload = loadTransactions;